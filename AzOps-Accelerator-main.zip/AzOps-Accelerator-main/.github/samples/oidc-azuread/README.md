This folder contains examples on how to leverage Federated workload credentials in Azure AD with AzOps/GitHub Actions.

Instruction on how to configure the service principal in Azure AD can be found at https://github.com/azure/azops/wiki/github-oidc